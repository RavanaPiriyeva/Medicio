<?php
/**
 * Update version
 *
 * @link       https://shapedplugin.com/
 * @since      2.1.7
 *
 * @package    WP_Carousel_Free
 * @subpackage WP_Carousel_Free/includes/updates
 */

/**
 * Update version.
 */
update_option( 'wp_carousel_free_version', '2.1.7' );
update_option( 'wp_carousel_free_db_version', '2.1.7' );
