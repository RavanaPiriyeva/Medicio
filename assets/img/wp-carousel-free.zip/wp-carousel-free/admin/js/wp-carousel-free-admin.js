jQuery(document).ready(function ($) {

    /**
     * Admin Preloader.
     */
    $(".sp_wpcp_shortcode_generator .wpcf-wrapper").css("visibility", "hidden");
    $(".sp_wpcp_shortcode_generator .wpcf-wrapper").css("visibility", "visible");
    $(".sp_wpcp_shortcode_generator .wpcf-wrapper").css("background", "#fff");
    $(".sp_wpcp_shortcode_generator .wpcf-wrapper li").css("opacity", 1);
});